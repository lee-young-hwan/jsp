package com.example.libs.model;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class MemberDao {
	public static int register(MemberVO member) throws SQLException {
		Connection conn = DBConnection.getConnection();		// 2, 3
		String sql = "{ call sp_member_insert(?,?,?,?,?,?,?) }";
		CallableStatement cstmt = conn.prepareCall(sql);	// 4
		cstmt.setString(1, member.getUserid());
		cstmt.setString(2, member.getPasswd());
		cstmt.setString(3, member.getName());
		cstmt.setString(4, member.getEmail());
		cstmt.setString(5, member.getGender());
		cstmt.setString(6, member.getCity());
		cstmt.setInt(7, member.getAge()); // 여기까지가 완전한 SQL문장
		
		int row = cstmt.executeUpdate(); // 5 반응한 row의 개수
		DBClose.close(conn, cstmt); // 6
		return row;
	}
}
